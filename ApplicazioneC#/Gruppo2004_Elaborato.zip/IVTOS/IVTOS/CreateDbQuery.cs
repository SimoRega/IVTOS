﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IVTOS
{
    class CreateDbQuery
    {

        public static string allInsert()
        {
            
        }
    }
}
