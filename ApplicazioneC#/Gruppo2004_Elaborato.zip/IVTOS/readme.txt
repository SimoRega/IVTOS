Per accedere all'applicativo inserire uno dei seguenti username: player admin spettatore
Inserire i dati corretti nell'area Autenticazione MySQL. Il campo password non è rilevante per accedere all'applicativo.
In base all'username inserito si aprirà una finestra differente, le varie funzionalità sono specificate nella relazione.

Una volta premuto il tasto login l'applicativo creerà il database il quale verrà popolato subito dopo.
Alla prima apertura compariranno 2 messaggi di procedura avvenuta correttamente, dopo di chè si aprirà in automatico la finestra richiesta